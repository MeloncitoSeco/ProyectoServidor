# ProyectoServidor

Antes de empezar hay que ejecutar el archivo creacionBBDD.sql

La pagina principal es PagPrincipal.php

La base de datos viene con 2 publicaciones y 3 fotos de prueba

Cuenta con dos hojas de estilos de css la primera es de PagPrincipal y la segunda es de foro

Los comentarios que tiene  //TODO es porque he usado una extension de VSCode que me localiza los To do (los "haceres") para saber que me queda por hacer

Si al final pone VVV es que esta completado  menos los sen 1,2,3 que se usan para localizar las SENtencias