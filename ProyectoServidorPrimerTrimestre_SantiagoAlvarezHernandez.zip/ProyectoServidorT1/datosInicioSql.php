<?php
$host = "127.0.0.1";
$tabla = "servidor";
$usuario = 'root';
$clave = '';

?>